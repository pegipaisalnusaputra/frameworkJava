package com.proyek.library.entity;

public class Loan {
    
}

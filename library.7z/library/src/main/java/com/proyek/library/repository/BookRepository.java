package com.proyek.library.repository;
import com.proyek.library.entity.Book;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface BookRepository extends JpaRepository<Book, Long> {
    //method to save a book (create/update)
    @Override
    <S extends Book> S save(S entity);

    //Method to find a book by Id (Read)
    @Override
    Optional<Book> findById(Long id);

    //Method to find all books (Read)
    @Override
    List<Book> findAll();

    //Method to delete a book by ID (Delete)
    @Override
    void deleteById(Long id);
}

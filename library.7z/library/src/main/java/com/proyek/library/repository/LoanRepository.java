package com.proyek.library.repository;

public class LoanRepository {
    
}
